package Chapter_2;

public class WrongTypeDataException extends Exception {
    public WrongTypeDataException(String description) {
        super(description);
    }
}
