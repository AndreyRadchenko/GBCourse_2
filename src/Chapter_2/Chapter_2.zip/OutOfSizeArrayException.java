package Chapter_2;

public class OutOfSizeArrayException extends Exception {
    public OutOfSizeArrayException(String description) {
        super(description);
    }
}
